package com.mugrp.giftshuffler.dao;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Stream;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import generated.FamilyMember;
import generated.GiftExchangeHistory;

/*
* GiftShufflerDao contract implementation
* 
* @author	sshish
* @version	1.0
* @since	3-4-2019
*/

@Component
public class GiftShufflerDaoImpl implements GiftShufflerDao {

	private List<FamilyMember> members;
	private List<GiftExchangeHistory> exchangeHistory;
	private static final Logger logger = LogManager.getLogger(GiftShufflerDaoImpl.class);

	/**
	 * Get list of members from dat file
	 * 
	 * @return List<FamilyMember>
	 */
	@Override
	public List<FamilyMember> getFamilyMembers() throws Exception {

		if (members == null) {
			members = new ArrayList<FamilyMember>();

			try {
				String fileName = "src/main/resources/data/members.dat";
				Path file = Paths.get(fileName);
				Stream<String> lines = Files.lines(file, StandardCharsets.UTF_8);

				for (String line : (Iterable<String>) lines::iterator) {

					String memberData[] = line.split(",");
					FamilyMember familyMember = new FamilyMember();
					familyMember.setMemberId(Integer.parseInt(memberData[0]));
					familyMember.setFirstName(memberData[1]);
					familyMember.setLastName(memberData[2]);
					familyMember.setGender(memberData[3]);
					members.add(familyMember);
				}
			} catch (Exception ex) {
				logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception", ex);
				throw ex;
			}
		}
		return members;
	}

	/**
	 * Populate gift exchange history from exchange history from dat file
	 * 
	 * @return List<GiftExchangeHistory>
	 */
	@Override
	public List<GiftExchangeHistory> getGiftExchangeHistory() throws Exception {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");

		if (exchangeHistory == null) {
			exchangeHistory = new ArrayList<GiftExchangeHistory>();

			try {
				String fileName = "src/main/resources/data/giftexchangehistory.dat";
				Path file = Paths.get(fileName);
				Stream<String> lines = Files.lines(file, StandardCharsets.UTF_8);

				for (String line : (Iterable<String>) lines::iterator) {

					String giftExchangeRecord[] = line.split(",");
					GiftExchangeHistory giftExchange = new GiftExchangeHistory();

					giftExchange.setExchangeId(Integer.parseInt(giftExchangeRecord[0]));
					giftExchange.setMemberId(Integer.parseInt(giftExchangeRecord[1]));
					giftExchange.setRecipientMemberId(Integer.parseInt(giftExchangeRecord[2]));
					giftExchange.setExchangeDate(toXMLGregorianCalendar(simpleDateFormat.parse(giftExchangeRecord[3])));
					exchangeHistory.add(giftExchange);
				}

			} catch (Exception ex) {
				logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception", ex);
				throw ex;
			}
		}
		return exchangeHistory;
	}

	/**
	 * Convert simple date to XMLGregorianCalendar format
	 * @param date
	 * @return XMLGregorianCalendar date 
	 */
	public XMLGregorianCalendar toXMLGregorianCalendar(Date date) {

		GregorianCalendar gCalendar = new GregorianCalendar();
		gCalendar.setTime(date);
		XMLGregorianCalendar xmlCalendar = null;
		try {
			xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCalendar);
		} catch (DatatypeConfigurationException ex) {

		}
		return xmlCalendar;
	}

	public List<FamilyMember> getMembers() {
		return members;
	}

	public void setMembers(List<FamilyMember> members) {
		this.members = members;
	}

	public List<GiftExchangeHistory> getExchangeHistory() {
		return exchangeHistory;
	}

	public void setExchangeHistory(List<GiftExchangeHistory> exchangeHistory) {
		this.exchangeHistory = exchangeHistory;
	}
}
