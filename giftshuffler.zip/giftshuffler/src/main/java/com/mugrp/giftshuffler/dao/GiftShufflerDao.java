package com.mugrp.giftshuffler.dao;

import java.util.List;

import generated.FamilyMember;
import generated.GiftExchangeHistory;

/*
* GiftShufflerDao contract 
* 
* @author	sshish
* @version	1.0
* @since	3-4-2019
*/

public interface GiftShufflerDao {

	public List<FamilyMember> getFamilyMembers() throws Exception;
	public List<GiftExchangeHistory> getGiftExchangeHistory() throws Exception;
}
