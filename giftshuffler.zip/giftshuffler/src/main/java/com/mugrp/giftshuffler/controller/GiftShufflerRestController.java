package com.mugrp.giftshuffler.controller;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mugrp.giftshuffler.GiftShuffler;
import com.mugrp.giftshuffler.GiftShufflerImpl;

import generated.FamilyMember;
import generated.GiftExchange;

/*
* GiftShufflerRestController contract 
* 
* @author	sshish
* @version	1.0
* @since	3-4-2019
*/

@RestController
public class GiftShufflerRestController {

	private GiftShufflerImpl giftShuffler;
	private static final Logger logger = LogManager.getLogger(GiftShufflerRestController.class);
	
	GiftShufflerRestController() throws Exception{
		giftShuffler = new GiftShufflerImpl();
	}
	
	@RequestMapping(value = "/members", method = RequestMethod.GET)
	@ResponseBody
	public List<FamilyMember> getFamilyMembers() {

		try {
				logger.info("Get family members");
				return giftShuffler.getFamilyMembers();
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception",ex);
			throw ex;
		}
	}
	
	@RequestMapping(value = "/members/{id}", method = RequestMethod.GET)
	@ResponseBody
	public FamilyMember getFamilyMember(@PathVariable("id") Integer memberId) {

		try {
				logger.info("Get family member");
				return giftShuffler.getFamilyMember(memberId);
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception",ex);
			throw ex;
		}
	}
	
	@RequestMapping(value = "/members", method = RequestMethod.POST)
	@ResponseBody
	public String addFamilyMember(@RequestBody FamilyMember familyMember) {

		try {
				logger.info("Add new family member");
				return giftShuffler.addFamilyMember(familyMember);
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception",ex);
			throw ex;
		}
	}
	
	
	@RequestMapping(value = "/members/{id}", method = RequestMethod.PUT)
	@ResponseBody
	public String updateFamilyMember(@RequestBody FamilyMember familyMember, @PathVariable("id") Integer memberId) {

		try {
				logger.info("Update family member id :" + memberId );
				return giftShuffler.updateFamilyMember(familyMember,memberId);
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception",ex);
			throw ex;
		}
	}
	
	
	@RequestMapping(value = "/gift_exchange", method = RequestMethod.GET)
	@ResponseBody
	public List<GiftExchange> giftExchange() {

		try {
				logger.info("Gift exchange");
				return giftShuffler.giftExchange();
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception",ex);
			throw ex;
		}
	}
	
	@RequestMapping(value = "/members/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public String deleteFamilyMember(@PathVariable("id") Integer memberId) {

		try {
				logger.info("Delete family member");
				return giftShuffler.deleteFamilyMember(memberId);
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception",ex);
			throw ex;
		}
	}
}



