package com.mugrp.giftshuffler.controller;

import java.lang.reflect.Member;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import generated.FamilyMember;

@XmlRootElement(name = "members")
public class FamilyMembers {

    @XmlElement(required = true)
    public List<FamilyMember> members;

    public List<FamilyMember> getData() {
        return members;
    }

    public void setData(List<FamilyMember> members) {
        this.members = members;
    }
}
