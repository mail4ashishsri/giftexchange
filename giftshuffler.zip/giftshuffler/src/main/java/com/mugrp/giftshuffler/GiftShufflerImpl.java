package com.mugrp.giftshuffler;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mugrp.giftshuffler.dao.GiftShufflerDao;
import com.mugrp.giftshuffler.dao.GiftShufflerDaoImpl;

import generated.FamilyMember;
import generated.GiftExchange;
import generated.GiftExchangeHistory;

/*
 * GiftShuffler contract implementation
 * 
 * @author	sshish
 * @version	1.0
 * @since	3-4-2019
 */

@Component
public class GiftShufflerImpl implements GiftShuffler {

	private List<FamilyMember> members;
	private List<GiftExchangeHistory> exchangeHistory;
	private static final Logger logger = LogManager.getLogger(GiftShufflerImpl.class);

	@Value("${gift.exchange.locking.years}")
	private Integer giftLockingYears;
	
	private GiftShufflerDaoImpl giftShufflerDao;

	public GiftShufflerImpl() throws Exception {
		initialize();
	}

	private void initialize() throws Exception {

		giftShufflerDao = new GiftShufflerDaoImpl();
		setMembers(giftShufflerDao.getFamilyMembers());
		setExchangeHistory(giftShufflerDao.getGiftExchangeHistory());
	}

	/**
	 * It will randomly exchange gifts between family members
	 * 
	 * @return List<GiftExchange>
	 */
	@Override
	public List<GiftExchange> giftExchange() {

		List<GiftExchange> giftExchange = new ArrayList<GiftExchange>();
		for (FamilyMember member : getMembers()) {
			List<Integer> eligibleMembers = new ArrayList<Integer>();
			List<Integer> myFamilyMembers = getMyFamilyMembers(member);
			eligibleMembers = getEligibleMemebers(myFamilyMembers, giftExchange, member);
			exchangeGift(giftExchange, eligibleMembers, member);
		}
		return giftExchange;
	}

	/**
	 * Fetch list of all family members
	 * 
	 * @return List<FamilyMember>
	 */
	@Override
	public List<FamilyMember> getFamilyMembers() {
		return getMembers();
	}

	/**
	 * Get member
	 * 
	 * @param memberId is to filter family member
	 * @return List<FamilyMember>
	 */
	@Override
	public FamilyMember getFamilyMember(Integer memberId) {

		FamilyMember familyMember = getMembers().stream().filter(m -> m.getMemberId() == memberId).findAny().get();
		return familyMember;
	}

	/**
	 * Add family member
	 * 
	 * @param familyMember is to add new family member
	 * @return String
	 */
	@Override
	public String addFamilyMember(FamilyMember familyMember) {

		try {
			Integer uid = getNextId(getMembers());

			FamilyMember member = new FamilyMember();
			member.setMemberId(uid);
			member.setFirstName(familyMember.getFirstName());
			member.setLastName(familyMember.getLastName());
			member.setGender(familyMember.getGender());
			members.add(member);

			return "Member added successfully";
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception", ex);
			return "Request failed";
		}

	}

	/**
	 * Generate new member id
	 * 
	 * @param <FamilyMember> is to find current members id
	 * @return String
	 */
	@Override
	public Integer getNextId(List<FamilyMember> members) {

		FamilyMember member = Collections.max(members, Comparator.comparing(v -> v.getMemberId()));
		return (member.getMemberId() + 1);
	}

	/**
	 * Generate new member id
	 * 
	 * @param              List<FamilyMember> is list of family members already
	 *                     received the gift
	 * @param              List<Integer> is list of eligible family members
	 * @param FamilyMember is looking for someone randomly to exchange gift
	 * @return nothing
	 */
	@Override
	public void exchangeGift(List<GiftExchange> giftExchange, List<Integer> eligibleMembers, FamilyMember member) {

		try {
			GiftExchange exchange = new GiftExchange();
			Random rand = new Random();

			Integer recipientId = eligibleMembers.get(rand.nextInt(eligibleMembers.size()));
			exchange.setMemberId(member.getMemberId());
			exchange.setRecipientMemberId(recipientId);
			giftExchange.add(exchange);

		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception", ex);
		}
	}

	/**
	 * Generate new member id
	 * 
	 * @param              List<Integer> is list of member ids excluding member who
	 *                     wants to exchange gift
	 * @param              List<GiftExchange> is list of already exchanged gift
	 * @param FamilyMember is looking for someone to exchange gift
	 * @return List<Integer>
	 */
	@Override
	public List<Integer> getEligibleMemebers(List<Integer> memberIds, List<GiftExchange> giftExchange,
			FamilyMember member) {

		List<Integer> eligibleMembers = new ArrayList<Integer>();
		for (Integer memberId : memberIds) {

			boolean isValid = checkGiftExchangeLockingPeriod(member.getMemberId(), memberId);
			if (isValid) {
				long received = giftExchange.stream().filter(t -> t.getRecipientMemberId() == memberId).count();
				if (received == 0) {
					eligibleMembers.add(memberId);
				}
			}
		}

		return eligibleMembers;
	}

	/**
	 * Get list of individuals family members
	 * 
	 * @param FamilyMember is individual looking for his/her family members
	 * @return List<Integer>
	 */
	@Override
	public List<Integer> getMyFamilyMembers(FamilyMember member) {

		return getMembers().stream().filter(i -> (i.getMemberId() != member.getMemberId())).map(i -> i.getMemberId())
				.collect(Collectors.toList());
	}

	/**
	 * Validate member gift locking period
	 * 
	 * @param individualId is individual looking for his/her family members
	 * @return List<Integer>
	 */
	@Override
	public boolean checkGiftExchangeLockingPeriod(int individualId, Integer otherMember) {
		Calendar lockingPeriod = Calendar.getInstance();
		lockingPeriod.add(Calendar.YEAR, -3);

		long exchangeCount = getExchangeHistory().stream().filter(t -> (t.getMemberId() == individualId)).filter(
				t -> t.getExchangeDate().toGregorianCalendar().getTimeInMillis() > lockingPeriod.getTimeInMillis())
				.count();

		return exchangeCount > 0 ? false : true;
	}

	/**
	 * Update family members
	 * 
	 * @param familyMember family member details
	 * @param memberId     member id
	 * @return String
	 */
	@Override
	public String updateFamilyMember(FamilyMember familyMember, Integer memberId) {
		try {
			for (FamilyMember member : getMembers()) {
				if (member.getMemberId() == memberId) {
					member.setFirstName(familyMember.getFirstName());
					member.setLastName(familyMember.getLastName());
					member.setGender(familyMember.getGender());
					return "Updated";
				}
			}
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception", ex);
			return "Request failed";
		}

		return "Not a family member";
	}

	/**
	 * Delete family members
	 * 
	 * @param memberId member id
	 * @return String
	 */
	@Override
	public String deleteFamilyMember(Integer memberId) {

		try {
			getMembers().removeIf(m -> (m.getMemberId() == memberId));
			return "Deleted";
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in exception", ex);
			return "Request failed";
		}
	}

	public List<FamilyMember> getMembers() {
		return members;
	}

	public void setMembers(List<FamilyMember> members) {
		this.members = members;
	}

	public List<GiftExchangeHistory> getExchangeHistory() {
		return exchangeHistory;
	}

	public void setExchangeHistory(List<GiftExchangeHistory> exchangeHistory) {
		this.exchangeHistory = exchangeHistory;
	}
}
