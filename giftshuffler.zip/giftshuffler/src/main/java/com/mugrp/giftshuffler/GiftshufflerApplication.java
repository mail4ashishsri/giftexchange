package com.mugrp.giftshuffler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.mugrp.giftshuffler")
public class GiftshufflerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiftshufflerApplication.class, args);
	}

}
