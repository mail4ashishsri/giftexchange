package com.mugrp.giftshuffler;

import java.util.List;

import generated.FamilyMember;
import generated.GiftExchange;

/*
* GiftShuffler contract 
* 
* @author	sshish
* @version	1.0
* @since	3-4-2019
*/

public interface GiftShuffler {

	public List<GiftExchange> giftExchange();

	public List<FamilyMember> getFamilyMembers();

	public FamilyMember getFamilyMember(Integer memberId);

	public String addFamilyMember(FamilyMember FamilyMember);

	public String updateFamilyMember(FamilyMember familyMember, Integer memberId);

	public String deleteFamilyMember(Integer memberId);

	public Integer getNextId(List<FamilyMember> members);

	public void exchangeGift(List<GiftExchange> giftExchange, List<Integer> eligibleMembers, FamilyMember member);

	public List<Integer> getEligibleMemebers(List<Integer> memberIds, List<GiftExchange> giftExchange,
			FamilyMember member);

	public List<Integer> getMyFamilyMembers(FamilyMember member);

	public boolean checkGiftExchangeLockingPeriod(int individualId, Integer otherMember);
}
