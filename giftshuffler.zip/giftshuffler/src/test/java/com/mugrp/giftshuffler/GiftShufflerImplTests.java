package com.mugrp.giftshuffler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import generated.FamilyMember;
import generated.GiftExchange;

@RunWith(SpringRunner.class)
public class GiftShufflerImplTests {

	//@Mock
	public List<FamilyMember> members;
	
	//@Mock
	FamilyMember member1;

	//@Mock
	FamilyMember member2;
	
	FamilyMember member3;
	 
	
	//@InjectMocks
	public GiftShufflerImpl giftShuffler;

	@Before
	public void setup() throws Exception {
		giftShuffler = new GiftShufflerImpl();
		members = new ArrayList<FamilyMember>();
		
		member1 = new FamilyMember();
		member1.setMemberId(1);
		member1.setFirstName("Reeti");
		member1.setLastName("Kapoor");
		member1.setGender("F");
		
		member2 = new FamilyMember();
		member2.setMemberId(2);
		member2.setFirstName("Amit");
		member2.setLastName("Kapoor");
		member2.setGender("M");
		
		member3 = new FamilyMember();
		member3.setMemberId(3);
		member3.setFirstName("Krishna");
		member3.setLastName("Kapoor");
		member3.setGender("F");
		
		members = Arrays.asList(member1, member2);
		giftShuffler.setMembers(members);
	}

	/*
	 * @Test public void testGiftShufflerImpl_exchangeGift() { List<GiftExchange>
	 * result = giftShuffler.giftExchange(); }
	 */

	@Test
	public void testGiftShufflerImpl_GetFamilyMembers() {

		List<FamilyMember> result = giftShuffler.getFamilyMembers();
		assertNotNull(result);
		assertEquals(2, result.size());
	}

	@Test
	public void testGiftShufflerImpl_GetFamilyMember() {
		
		FamilyMember result = giftShuffler.getFamilyMember(2);
		assertNotNull(result);
		assertEquals(2, result.getMemberId());
		assertEquals("Amit", result.getFirstName());
		assertEquals("Kapoor", result.getLastName());
		assertEquals("M", result.getGender());
	}
	
	@Test
	public void testGiftShufflerImpl_AddFamilyMember() throws Exception {
		//List<FamilyMember>
		
		//GiftShufflerImpl giftShufflerImpl = new GiftShufflerImpl();
		//giftShufflerImpl.setMembers(new ArrayList<FamilyMember>());
		String result = giftShuffler.addFamilyMember(member3);
		assertNotNull(result);
		assertEquals("Request failed", result);
	}
	
	
	@Test
	public void testGiftShufflerImpl_UpdateFamilyMember() {
		String result = giftShuffler.updateFamilyMember(member3,2);
		assertNotNull(result);
		assertEquals("Updated", result);
	}
	
	@Test
	public void testGiftShufflerImpl_DeleteFamilyMember() {
		String result = giftShuffler.deleteFamilyMember(2);
		assertNotNull(result);
		assertEquals("Request failed", result);
	}
	
	@Test
	public void testGiftShufflerImpl_GetNextFamilyMemberId() {
		Integer result = giftShuffler.getNextId(members);
		assertNotNull(result);
		assertTrue(result.equals(3));
	}
	
	@Test
	public void testGiftShufflerImpl_ExchangeGift() {
		List<GiftExchange> giftExchange = new ArrayList<GiftExchange>();
		List<Integer> eligibleMembers = new ArrayList<Integer>();
		eligibleMembers.add(1);
		eligibleMembers.add(2);
		
		giftShuffler.exchangeGift(giftExchange, eligibleMembers, member3);
		assertEquals(1, giftExchange.size());
	}
	
	@Test
	public void testGiftShufflerImpl_GetEligibleMemebers() {
		List<GiftExchange> giftExchanges = new ArrayList<GiftExchange>();
		GiftExchange giftExchange = new GiftExchange();
		giftExchange.setMemberId(1);
		giftExchange.setRecipientMemberId(2);
		giftExchanges.add(giftExchange);
		
		List<Integer> memberIds = new ArrayList<Integer>();
		memberIds.add(1);
		memberIds.add(2);
		
		List<Integer> result = giftShuffler.getEligibleMemebers(memberIds, giftExchanges, member3);
		assertEquals(1, result.size());
	}
	
	
	@Test
	public void testGiftShufflerImpl_GetMyFamilyMembers() {
		List<Integer> result = giftShuffler.getMyFamilyMembers(member3);
		assertEquals(2, result.size());
	}

}
