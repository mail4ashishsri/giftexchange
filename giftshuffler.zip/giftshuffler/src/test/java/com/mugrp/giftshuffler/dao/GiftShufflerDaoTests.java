package com.mugrp.giftshuffler.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.assertj.core.util.Arrays;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import generated.FamilyMember;
import generated.GiftExchangeHistory;

@RunWith(SpringRunner.class)
public class GiftShufflerDaoTests {

	private GiftShufflerDaoImpl giftShufflerDaoImpl;
	
	@Mock
	public List<FamilyMember> members;
	
	@Mock
	List<GiftExchangeHistory> exchangeHistory;
	
	private Date exchangeDate;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
	
	@Mock
	FamilyMember member1;
	
	@Mock
	GiftExchangeHistory giftExchange1;

	@Mock
	GiftExchangeHistory giftExchange2;
	
	@Before
	public void setup() throws ParseException {
		giftShufflerDaoImpl = new GiftShufflerDaoImpl();
		members = new ArrayList<FamilyMember>();
		members.add(member1);
		
		exchangeHistory = new ArrayList<GiftExchangeHistory>();
		exchangeHistory.add(giftExchange1);
		exchangeHistory.add(giftExchange2);
		exchangeDate = simpleDateFormat.parse("31-Dec-2016 23:37:50");
	}

	@Test
	public void testGiftShufflerDaoImpl_GetMembers() throws Exception {
		
		giftShufflerDaoImpl.setMembers(members);
		List<FamilyMember> result = giftShufflerDaoImpl.getFamilyMembers();
		assertEquals(1, result.size());
		assertNotNull(result);
	}

	@Test
	public void testGiftShufflerDaoImpl_GetGiftHistory() throws Exception {

		giftShufflerDaoImpl.setExchangeHistory(exchangeHistory);
		List<GiftExchangeHistory> result = giftShufflerDaoImpl.getGiftExchangeHistory();
		assertEquals(2, result.size());
		assertNotNull(result);
	}
	
	@Test
	public void testGiftShufflerDaoImpl_ToXMLGregorianCalendar() throws Exception {

		XMLGregorianCalendar result = giftShufflerDaoImpl.toXMLGregorianCalendar(exchangeDate);
		assertEquals("2016-12-31T23:37:50.000+05:30", result.toString());
	}
}
