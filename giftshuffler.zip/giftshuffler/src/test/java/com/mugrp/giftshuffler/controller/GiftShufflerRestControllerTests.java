package com.mugrp.giftshuffler.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import generated.FamilyMember;

@RunWith(SpringRunner.class)
@WebMvcTest(value = GiftShufflerRestController.class)
public class GiftShufflerRestControllerTests {

	@Autowired
	private MockMvc mockMvc;

	GiftShufflerRestController giftShufflerRestController;


	@Test
	public void GiftShufflerRestController_getFamilyMembers() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/members").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	@Test
	public void GiftShufflerRestController_getFamilyMember() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/members/1").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	@Test
	public void GiftShufflerRestController_addFamilyMember() throws Exception {

		String userJson = "{\"firstName\":\"Ashish\",\"lastName\":\"Sri\",\"gender\":\"M\"}";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/members").accept(MediaType.APPLICATION_JSON)
				.content(userJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	@Test
	public void GiftShufflerRestController_updateFamilyMember() throws Exception {

		String userJson = "{\"firstName\":\"Ashish\",\"lastName\":\"Sri\",\"gender\":\"M\"}";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/members/2").accept(MediaType.APPLICATION_JSON)
				.content(userJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	@Test
	public void GiftShufflerRestController_exchangeGift() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/gift_exchange").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}
}
